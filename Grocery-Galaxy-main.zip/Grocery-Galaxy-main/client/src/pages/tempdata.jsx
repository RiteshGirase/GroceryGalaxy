import background2 from "../Assets/Images/busbooking.jpg";
import background1 from "../Assets/Images/bookbus.png";
var items = [
    {
      heading: "Welcome to",
      img:"https://www.tastingtable.com/img/gallery/12-signs-you-should-avoid-grocery-store-products-before-buying-them/intro-1679264356.webp"
    },
    {
      heading: "Welcome to",
      img:"https://media.istockphoto.com/id/171302954/photo/groceries.jpg?s=612x612&w=0&k=20&c=D3MmhT5DafwimcYyxCYXqXMxr1W25wZnyUf4PF1RYw8=",
    },
    {
      heading: "Welcome to",
      img:
        "https://images.unsplash.com/photo-1588964895597-cfccd6e2dbf9?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8Z3JvY2VyeXxlbnwwfHwwfHx8MA%3D%3D",
    },
  ];
  export default items;